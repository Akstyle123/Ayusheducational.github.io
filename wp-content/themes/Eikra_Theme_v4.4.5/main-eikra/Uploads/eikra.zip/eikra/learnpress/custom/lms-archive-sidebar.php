<?php
/**
 * @author  RadiusTheme
 * @since   1.3
 * @version 3.2
 */

if ( is_active_sidebar( 'archive-courses-sidebar' ) ) {
	dynamic_sidebar( 'archive-courses-sidebar' );
}