<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Layerslider_Vc
 */
class WPBakeryShortCode_Layerslider_Vc extends WPBakeryShortCode {
}
