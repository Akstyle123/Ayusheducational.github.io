<?php
   class Redux_Customizer_Control_radio extends Redux_Customizer_Control {
     public $type = "redux-radio";
   }